(function()
{
	var app = angular.module('bookingApp');
	
	app.factory('roomDataService',  function($http) 
	{
			//-- Retrieving data from the json file 

			var data = function() 
			{
				return $http.get('javaScript/rooms/dataset.json')
						.then(function(response){ 
							return response;
						});
			};
			
			
			var optimizedData = function(data) 
			{
				var unique = [],
				keys = [];		
				
				// Filtering the results, producing a new array with unique room objects
				angular.forEach(data, function(item) 
				{
					var key = item['Type'];
					if(keys.indexOf(key) === -1) 
					{
						keys.push(key);
						unique.push(item);					
					}						
				});
				
				//-- Adding available rooms number to the array
				angular.forEach(unique, function(uniqueItem)
				{	
					var cnt=0;		
					
					angular.forEach(data, function(item)
					{
						if(item.Type == uniqueItem.Type){
							uniqueItem.RoomsNum = ++cnt;
						}
					});	
				});
				return unique;
			};
			
			return {
				getData: data,
				optimizeData: optimizedData
			};
		
	});
	
	// Service taking care of all the shopping cart functions
	app.factory('cartService', function() 
	{	
		var addToCart = function(cartArray, obj) 
		{		
			var pointer = null;
			angular.forEach(cartArray, function(item, key)
			{	
				if (item.type == obj.type){
					pointer = key;					
				}	
			});
			
			if (pointer == null){
				cartArray.push(obj);
			}
			else{
				if(cartArray[pointer].quantity < cartArray[pointer].available){
					cartArray[pointer].quantity++;
				}
			}
			return cartArray;
		};

		var removeFromCart = function (cartArray, pointer) 
		{
			cartArray.splice(pointer, 1);
			return cartArray;
		};
		
		var increaseRoomNum = function (cartArray, pointer) 
		{
			if(cartArray[pointer].quantity < cartArray[pointer].available){
				cartArray[pointer].quantity++;
			}
			return cartArray;
		};

		var decreaseRoomNum = function (cartArray, pointer) 
		{
			if(cartArray[pointer].quantity > 1 ){
				cartArray[pointer].quantity--;
			}
			return cartArray;
		};
		
		return {
			addRoom: addToCart,
			removeRoom: removeFromCart,
			increaseRoomQnt: increaseRoomNum,
			decreaseRoomQnt: decreaseRoomNum
		};

	});
	
	// Calculates the number of days between the arrival and depature dates.
	app.service('timeService', function()
	{
		// Using this method to avoid timezone inconsistencies
		this.getDuration = function(startDate, endDate) 
		{
			var dayInMillis = 1000*60*60*24;
			
			// Converting string date format to be recognizable from javaScript Date function
			startDate = startDate.substr(6, 4)+"-"+startDate.substr(3, 2)+"-"+startDate.substr(0, 2);
			endDate = endDate.substr(6, 4)+"-"+endDate.substr(3, 2)+"-"+endDate.substr(0, 2);
			
			// objects
			startDate = new Date(startDate);
			endDate = new Date(endDate);
			
			// milliseconds
			startDate = Date.UTC(startDate.getFullYear(), startDate.getMonth(), startDate.getDate());
			endDate = Date.UTC(endDate.getFullYear(), endDate.getMonth(), endDate.getDate());
			
			// duration

			return Math.floor((endDate - startDate) / dayInMillis);
		}

	});
	
})();
