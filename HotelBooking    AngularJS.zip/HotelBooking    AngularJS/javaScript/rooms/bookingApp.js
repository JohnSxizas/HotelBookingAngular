(function()
{
	angular.module('bookingApp', []);
})();